import { ToolbarChip } from "@patternfly/react-core";
import { createAction } from "typesafe-actions";

type FilterCategory = string;
type FilterValue = string | ToolbarChip;

export const addFilter = createAction("applicationToolbar/filter/add")<{
  group: FilterCategory;
  value: FilterValue;
}>();
export const removeFilter = createAction("applicationToolbar/filter/remove")<{
  group: FilterCategory;
  value: FilterValue | FilterValue[];
}>();
export const setFilter = createAction("applicationToolbar/filter/set")<{
  group: FilterCategory;
  value: FilterValue[];
}>();
export const clearAllFilters = createAction(
  "applicationToolbar/filter/clearAll"
)();
