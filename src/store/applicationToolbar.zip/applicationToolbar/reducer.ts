import { ButtonVariant, ToolbarChip } from "@patternfly/react-core";
import { ActionType, getType } from "typesafe-actions";
import { addFilter, removeFilter, setFilter, clearAllFilters } from "./actions";

export const stateKey = "applicationToolbar";

export type ApplicationToolbarState = Readonly<{
  filters: Map<string, ToolbarChip[]>;
  isEmpty: boolean;
}>;

export const defaultState: ApplicationToolbarState = {
  filters: new Map(),
  isEmpty: true,
};

export type ApplicationToolbarAction = ActionType<
  | typeof addFilter
  | typeof removeFilter
  | typeof setFilter
  | typeof clearAllFilters
>;

export const reducer = (
  state: ApplicationToolbarState = defaultState,
  action: ApplicationToolbarAction
): ApplicationToolbarState => {
  switch (action.type) {
    case getType(addFilter):
      return {
        ...state,
        ...action.payload,
        isOpen: true,
      };
    case getType(processing):
      return {
        ...state,
        isProcessing: true,
      };
    case getType(closeDialog):
      return defaultState;
    default:
      return state;
  }
};
